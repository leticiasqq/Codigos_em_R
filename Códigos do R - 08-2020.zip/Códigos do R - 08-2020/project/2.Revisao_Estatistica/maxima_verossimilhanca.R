################################################
####  O PRINCÍPIO DA MÁXIMA VEROSSIMILHANÇA  ###
################################################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

######
###  FUNÇÕES PRÓPRIAS QUE SERÃO USADAS
######

# função densidade de probabilidade da Normal
norm_dens <- function(x, media, desvio){
  y <- 1/sqrt(2*pi*desvio^2)*exp((-1/2*((x-media)/desvio^2)))
}

# função do negativo do log da verossimilhança da Normal
neg_log_lik <- function(x, parametros){
  # parâmetros para a distribuição Normal
  media <- parametros[1]
  desvio <- parametros[2]
  n <- length(x)
  # log da verossimilhança da Normal
  ll <- -(n/2)*log(2*pi*desvio^2) + (-1/(2*desvio^2))*sum((x-media)^2)
  # retornar o negativo para maximizar ao invés de minimizar 
  return(-ll)
}

# função do negativo do log da verossimilhança da Normal para uma regressão linear
ols_neg_log_lik <- function(y, x, parametros){
  # parâmetros para a distribuição Normal de uma regressão linear
  desvio <- parametros[1]
  betas <- parametros[-1]
  media <- cbind(1,x) %*% betas
  n <- length(x)
  # log da verossimilhança da Normal
  ll <- -(n/2)*log(2*pi*desvio^2) + (-1/(2*desvio^2))*sum((y-media)^2)
  # retornar o negativo para minimizar ao invés de maximizar
  return(-ll)
}

######
###  O VALOR x* QUE MAXIMIZA UMA FUNÇÃO f(x) É O MESMO QUE MINIMIZA -f(x)
######

# Por default, a maioria dos pacotes que usam algoritmos de otimização no R, aplicam
# a minimização de uma função qualquer. No nosso caso, estamos buscando os parametros
# que maximizam a função de verossimilhança para um problema. Para tratar isso, perceba 
# que multiplicamos a função de verossimilhança por -1 (return(-ll)). Para facilitar o 
# entendimento, abaixo gráficos que mostram que o valor que maximiza a função de verossimilhança
# é o mesmo que minimiza seu negativo

# gráfico da função do logaritmo da verossmilhança. Observe que estamos multiplicando por -1
# a função que já é o negativo (ou seja, voltando para o seu sinal)
plot(x = seq(from = -3, to = 3, by = 0.1),
     y = -1*sapply(seq(from = -3, to = 3, by = 0.1), 
                   FUN = neg_log_lik, par = c(0,1)),
     type = "l",
     ylab = "",
     xlab = "Valor da variável aleatória X", 
     main = "Log da Verossimilhança para Média=0 e Variância=1")

# gráfico do negativo do logaritmo da verossimilhança
plot(x = seq(from = -3, to = 3, by = 0.1),
     y = 1*sapply(seq(from = -3, to = 3, by = 0.1), 
                  FUN = neg_log_lik, par = c(0,1)),
     type = "l",
     ylab = "",
     xlab = "Valor da variável aleatória X", 
     main = "Negativo do Log da Verossimilhança para Média=0 e Variância=1")

######
###  EXEMPLO 1
######

# Nese exemplo, vamos mostrar como usar o princípio da máxima verossimilhança para encontrar
# os parâmetros de média e variância de uma amostra de uma variável aleatória que segue 
# uma distribuição Normal

# 1000 observações de X geradas a partir de uma distribuição normal com média 1 e desvio 2
x <- rnorm(n = 10000, mean = 1, sd = 2)

# Uma vez que temos uma função que deve ser maximizada e os parâmetros iniciais, podemos usar
# a função optim do pacote stats para obter as estimativas ótimas para a média e variância. 
# - par: atributo que recebe os valores iniciais dos parâmetros. A sequência é importante aqui, 
# pois definimos na função que o primeiro é a média e o segundo é a variância
# - fn: a função que deve ser minimizada. Por default, optim faz uma minimização e por isso
# definimos o negativo do logaritmo da verossimilhança dado que minimizar o inverso de uma 
# função é o mesmo que maximizá-la
# - method: o algoritmo numérico usado para solucionar o problema. 
# - hessian: se queremos (TRUE) ou não (FALSE) que a matriz hessiana do problema de otimização seja
# disponibilizada. Para mais detalhes use help(optim) ou em https://cran.r-project.org/web/packages/fitdistrplus/vignettes/Optimalgo.html
normal.fit <- stats::optim(par = c(1,1), 
                            fn = neg_log_lik, 
                            x = x, 
                            method = "BFGS",
                            hessian = TRUE)

# Resultado: Parâmetros encontrados para a média e variância (condição de primeira ordem). Observe
# que eles estão bem próximos dos valores usados para gerar a variavel aleatória
normal.fit$par 

# Resultado: matriz hessiana (condição de segunda ordem). Aqui, temos que avaliar se a matriz
# hessiana é negativa definida ou positiva definida nos pontos críticos encontrados na condição
# de primeira ordem. Como estamos com um problema de minimização (novamente, encontrar os valores 
# para a média e variância que minimizam o negativo da função de verossimilhança é o mesmo que 
# encontrar os valores que maximizam a função de verossimilhança), temos que verificar se nas 
# proximidades da matriz hessiana a função é "convexa". Isso só é possível se os menores principais
# líderes da matriz hessiana são positivos tornando-a positiva definida. 
normal.fit$hessian

# Determinante do primeiro menor principal líder
det(matrix(data = normal.fit$hessian[1], nrow = 1, ncol = 1))

# Determinante do segundo menor principal líder
det(matrix(data = normal.fit$hessian, nrow = 2, ncol = 2))

# Matriz de informação de Fisher
#  - Mais detalhes em https://rpubs.com/hudsonchavs/maxverosimilhanca
#  - Obida por (-hessiana)^(-1). A razão para não ser preciso multiplicar a matriz
# hessiana por -1 é que já fizemos a minimização usando o negativo da verossimilhança
fisher.information.normal.fit <- solve(normal.fit$hessian)

# Desvio padrão de cada estimador (beta0, beta1, desvio)
#  - Mais detalhes em https://rpubs.com/hudsonchavs/maxverosimilhanca
#  - Usamos a raiz quadrada da diagonal principal 
standard.deviance.normal.fit <- sqrt(diag(fisher.information.normal.fit))

# Tabela com os parâmetros estimados, estatística t, desvio padrão do estimador e p-valor
t.normal.fit <- normal.fit$par/standard.deviance.normal.fit
pvalue.normal.fit <- 2*(1-pt(abs(t.normal.fit), length(x)-length(normal.fit$par)))
results.normal.fit <- cbind(normal.fit$par, standard.deviance.normal.fit, t.normal.fit, pvalue.normal.fit)
colnames(results.normal.fit) <- c("parâmetros", "desvio-padrão", "estatística t", "p-valor")
rownames(results.normal.fit) <- c("media", "desvio")
print(results.normal.fit, digits = 3)

######
###  EXEMPLO 2
######

# Neste exemplo vamos mostrar como obter os parâmetros de uma regressão linear simples
# por meio do método da máxima verossimilhança. Para isso, vamos gerar uma amostra de 
# y que é função de x e de um ruído. Porém, antes de gerar y com o ruído, saberemos o
# verdadeiro y dado que temos os verdadeiros parâmetros para a regressão linear.

# 1000 observações de x geradas a partir de uma distribuição normal com média 10 e desvio 1
ols.data.x <- rnorm(n = 10000, mean = 10, sd = 1)

# Parâmetros populacionais do modelo de regressão
beta0.true <- 3
beta1.true <- 8

# 1000 observações de y geradas a partir dos parâmetros populacionais e x
true.y <- beta0.true + beta1.true*ols.data.x

# 1000 observações geradas a partir dos dados populacionais com um termo de erro que segue uma 
# normal com média 0 e desvio 1
noise <- rnorm(n = 10000, mean = 0, sd = 1)
data.y <- true.y + noise 

# Uma vez que temos uma função que deve ser maximizada e os parâmetros iniciais, podemos usar
# a função optim do pacote stats para obter as estimativas ótimas para a média (agora uma média
# condicional que é função do vetor beta de parâmetros da regressão linear e a variância que deve
# ser a mesma do termo de erro). 
# - par: atributo que recebe os valores iniciais dos parâmetros. A sequência é importante aqui, 
# pois definimos na função que o primeiro é a média e o segundo é a variância
# - fn: a função que deve ser minimizada. Por default, optim faz uma minimização e por isso
# definimos o negativo do logaritmo da verossimilhança dado que minimizar o inverso de uma 
# função é o mesmo que maximizá-la
# - method: o algoritmo numérico usado para solucionar o problema. 
# - hessian: se queremos (TRUE) ou não (FALSE) que a matriz hessiana do problema de otimização seja
# disponibilizada. Para mais detalhes use help(optim) ou em https://cran.r-project.org/web/packages/fitdistrplus/vignettes/Optimalgo.html
ols.fit <- stats::optim(par = c(1,1,1), 
                           fn = ols_neg_log_lik, 
                           y = data.y,
                           x = ols.data.x, 
                           method = "BFGS", 
                           hessian = TRUE)

# resultado: parâmetros encontrados para desvio, beta0 e  beta1 (a ordem é a mesma da definida
# na função ols_neg_log_lik)
ols.fit$par

# Resultado: matriz hessiana (condição de segunda ordem). Aqui, temos que avaliar se a matriz
# hessiana é negativa definida ou positiva definida nos pontos críticos encontrados na condição
# de primeira ordem. Como estamos com um problema de minimização (novamente, encontrar os valores 
# para a média e variância que minimizam o negativo da função de verossimilhança é o mesmo que 
# encontrar os valores que maximizam a função de verossimilhança), temos que verificar se nas 
# proximidades da matriz hessiana a função é "convexa". Isso só é possível se os menores principais
# líderes da matriz hessiana são positivos tornando-a positiva definida. 
ols.fit$hessian

# Determinante do primeiro menor principal líder
det(matrix(data = ols.fit$hessian[1], nrow = 1, ncol = 1))

# Determinante do segundo menor principal líder
det(matrix(data = ols.fit$hessian[1:2,1:2], nrow = 2, ncol = 2))

# Determinante do terceiro menor principal líder
det(matrix(data = ols.fit$hessian, nrow = 3, ncol = 3))

# Matriz de informação de Fisher
#  - Mais detalhes em https://rpubs.com/hudsonchavs/maxverosimilhanca
#  - Obida por (-hessiana)^(-1). A razão para não ser preciso multiplicar a matriz
# hessiana por -1 é que já fizemos a minimização usando o negativo da verossimilhança
fisher_information <- solve(ols.fit$hessian)

# Desvio padrão de cada estimador (beta0, beta1, desvio)
#  - Mais detalhes em https://rpubs.com/hudsonchavs/maxverosimilhanca
#  - Usamos a raiz quadrada da diagonal principal 
standard_deviance <- sqrt(diag(fisher_information))

# Tabela com os parâmetros estimados, estatística t, desvio padrão do estimador e p-valor
t <- ols.fit$par/standard_deviance
pvalue <- 2*(1-pt(abs(t), length(ols.data.x)-length(ols.fit$par)))
results <- cbind(ols.fit$par, standard_deviance, t, pvalue)
colnames(results) <- c("parâmetros", "desvio-padrão", "estatística t", "p-valor")
rownames(results) <- c("desvio", "beta0", "beta1")
print(results, digits = 3)

# valor real e ajustado 
beta0.estimado <- ols.fit$par[2]
beta1.estimado <- ols.fit$par[3]
y.estimado <- beta0.estimado + beta1.estimado*ols.data.x
residuos <- true.y - y.estimado

# gráfico dos resíduos
plot(residuos, type = "l", xlab = "", ylab = "", main = "resíduos")

######
###  PONTO DE ATENÇÃO
######

# O método de máxima verossimilhança é bastante sensível aos valores iniciais usados no problema
# de otimização, principalmente para alguns métodos numéricos. Perceba que se você alterar apenas
# os valores iniciais para c(1,1,1) no problema de regressão linear simples e manter o método numérico, 
# os resultados encontrados são alterados. Como não é possível controlar os pontos iniciais bem como
# a escoha do método numérico, a maioria dos pacotes em R que estimam modelos econométricos, fazem
# uso de algum método de estimação a priori (mínimos quadrados ordinários, por exemplo) para encontrar
# parâmetros iniciais e usá-los posteriormente como parâmetros iniciais do método de máxima verossimilhança


###############################
###   REVISÃO ESTATÍSTICA   ###
###############################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

#####
###  PROBABILIDADE
#####

# Considere o experimento aleatório de jogar um copo de isopor no chão de uma 
# altura qualquer. O copo bate no chão e pode parar voltado para baixo, para cima ou 
# de lado. Tal experimento aleatório pode ser representado como segue:

# O espaço amostral s contem a coluna "pouso" que armazena os resultados possíveis
s <- data.frame(pouso = c("baixo", "alto", "lado"))

# variável aleatória
x <- c(1, 3, 5)

# distribuição de probabilidades associadas com cada valor da variável aleatória
px <- c(0.6, 0.3, 0.1)

# amostra aleatória com 500 observações obtida a partir da distribuição de probabilidade 
amostra <- sample(x, size = 500, replace = TRUE, prob = px)

# gráfico da amostra aleatória
hist(amostra, breaks = seq(1, 5, by = 0.25), 
     main = "500 observações discretas",
     xlab = "valores da variável aleatória discreta",
     ylab = "probabildade")

# A partir do gráfico temos 60% das observações com valores iguais a 1, 
# 30% com o valor 3 e 10% com o valor 5.

#####
###  DISTRIBUIÇÕES DE PROBABILIDADE BERNOULLI 
#####

# variável aleatória discreta
x <- c(0,1)

# distribuição de probabilidade
y <- c(0.25,0.75)

# gráfico da distribuição de probabilidade
plot(x,y,type="h",xlim=c(-1,2),ylim=c(0,1),lwd=2,col="blue",xlab="Variável aleatória",ylab="Probabilidade")
points(x,y,pch=16,cex=2,col="dark red")

#####
###  DISTRIBUIÇÕES DE PROBABILIDADE BINOMIAL
#####

# quantidade de repetições do experimento
n <- 10

# probabilidade de sucesso 
p <- 1/4

# quantidade de sucessos possíveis
k <- 0:10

# distribuição de probabilidade para cada possível k
p <- stats::dbinom(k,size=n,prob=p)

# gráfico da distribuição de probabilidade
plot(k,p,type="h",xlim=c(-1,11), ylim = c(0,0.5),lwd = 2, col = "blue",ylab = "probabilidade", xlab = "k sucessos")
points(k,p,pch=16,cex=2,col="dark red")

#####
###  DISTRIBUIÇÕES DE PROBABILIDADE POISSON
#####

# taxa média de ocorrência no intervalo de um ano
lambda <- 10

# quantidade de turistas falecendo no intervalo de um ano
k <- 0:15

# distribuição de probabilidade para cada possível k
p <- stats::dpois(x = k, lambda = lambda)

# gráfico da distribuição de probabilidade
plot(k,p,type="h",xlim=c(0,15), lwd = 2, col = "blue",ylab = "probabilidade", xlab = "quantidade de turistas falecendo no intervalo de um ano")
#plot(k, p, type = "h" )
points(k,p,pch=16,cex=2,col="dark red")

#####
###  DISTRIBUIÇÕES DE PROBABILIDADE EXPONENCIAL
#####

# taxa média de ocorrência 
lambda <- 1/5

# tempo até a ocorrência
t <- seq(0, 20, length.out = 100)

# distribuição de probabilidade exponencial 
p <- stats::dexp(x = t, rate = lambda)

# gráfico da distribuição de probabilidade
plot(t,p,type="l",xlim=c(0,15), lwd = 2, col = "blue",ylab = "lambda", xlab = "tempo entre a ocorrêcia de falhas")


#####
###  DISTRIBUIÇÕES DE PROBABILIDADE NORMAL
#####

# valores da variável aleatória X
x <- seq(from = -3, to =3, length.out = 200)
x2 <- seq(from = -5, to = 5, length.out = 200)

# médias
mu <- c(0,0,0)
mu2 <- c(-0.7,1,1.5)

# variâncias
sigma <- c(0.7,1,1.5)
sigma2 <- c(1,1,1)

# distribuição de probabilidade normal
p1 <- stats::dnorm(x = x, mean = mu[1], sd = sigma[1])
p2 <- stats::dnorm(x = x, mean = mu[2], sd = sigma[2])
p3 <- stats::dnorm(x = x, mean = mu[3], sd = sigma[3])
p4 <- stats::dnorm(x = x2, mean = mu2[1], sd = sigma2[1])
p5 <- stats::dnorm(x = x2, mean = mu2[2], sd = sigma2[2])
p6 <- stats::dnorm(x = x2, mean = mu2[3], sd = sigma2[3])

# dividir a tela em duas colunas
par(mfrow=c(1,2))

# gráfico da distribuição de probabilidade para a media constante
plot(x, p1, type = "l", xlim=c(-4,4), lwd = 2, col = "blue", ylab = "Densidade", xlab = "x",
     main = "Distribuição Normal - Média constante")
lines(x, p2, type = "l", xlim=c(-4,4), lwd = 3, col = "red")
lines(x, p3, type = "l", xlim=c(-4,4), lwd = 4, col = "black")
legend("topright", legend = c("sigma=0.7","sigma=1","sigma=1.5"), 
       col = c("blue","red", "black"), lwd = c(2,3,4))

# gráfico da distribuição de probabilidade para a variância constante
plot(x2, p4, type = "l", xlim=c(-6,6), lwd = 2, col = "blue", ylab = "Densidade", xlab = "x",
     main = "Distribuição Normal - Variância constante")
lines(x2, p5, type = "l", xlim=c(-6,6), lwd = 3, col = "red")
lines(x2, p6, type = "l", xlim=c(-6,6), lwd = 4, col = "black")
legend("topleft", legend = c("mu=-0.70","mu=1","mu=1.5"), 
       col = c("blue","red", "black"), lwd = c(2,3,4))


#####
###  DISTRIBUIÇÕES DE PROBABILIDADE t DE STUDENT
#####

# valores da variável aleatória X
x <- seq(from = -5, to = 5, length.out = 200)

# parâmetros da Normal padronizada
mu <- 0
sigma <- 1

# parâmetros da t de Student
upsilon <- c(2.5, 5, 100)

# distribuição de probabilidade normal padronizada
p <- stats::dnorm(x = x, mean = mu, sd = sigma)

# distribuição de probabilidade t de Student
p1 <- stats::dt(x = x, df = upsilon[1])
p2 <- stats::dt(x = x, df = upsilon[2])
p3 <- stats::dt(x = x, df = upsilon[3])

# gráfico da distribuição de probabilidade normal padronizada
plot(x, p, type = "l", xlim=c(-6,6), lwd = 5, col = "blue", ylab = "Densidade", xlab = "x",
     main = "")
lines(x, p1, type = "l", xlim=c(-6,6), lwd = 2, col = "red")
lines(x, p2, type = "l", xlim=c(-6,6), lwd = 3, col = "black")
lines(x, p3, type = "l", xlim=c(-6,6), lwd = 4, col = "grey")

legend("topleft", legend = c("N(0,1)","t(2.5)","t(5)", "t(100)"), 
       col = c("blue","red", "black", "grey"), lwd = c(5,2,3,4))


#####
###  CURTOSE DE DISTRIBUIÇÕES DE PROBABILIDADE
#####

# A normal padrão possui curtose K=3. Já a curtose da distribuição t é dada pela fórmula:
# K = 6/(ν−4) + 3 para ν > 4, infinito para 2 < ν ≤ 4, e indeterminado caso contrário. Exemplo
x <- seq(from = -4, to = 4, by = 0.01)
plot(x = x, y = stats::dt(x, df = 6), type = "l", ylim = c(0,0.4), col = 4, ylab = "f(x)")
lines(x = x, y = stats::dnorm(x), col = 2)
abline(h = 0)
legend("topleft", legend = c("t-Student", "Normal"), col = c(4, 2), lwd = c(1,1))

# Simulação para verificar a curtose de duas amostras aleatórias da T e Normal
set.seed(1)
n <- 10000000 # tamanho da amostra
samp.t <- stats::rt(n, df = 6)  #obtém a amostra da distribuição t
samp.n <- stats::rnorm(n)  # obtém a amostra da distribuição normal
media.t <- mean(samp.t)
media.n <- mean(samp.n)
var.t <- sd(samp.t)^2
var.n <- sd(samp.n)^2
(k.t <- 1/n*sum((samp.t - media.t)^4) / (var.t)^2)
(k.n <- 1/n*sum((samp.n - media.n)^4) / (var.n)^2)

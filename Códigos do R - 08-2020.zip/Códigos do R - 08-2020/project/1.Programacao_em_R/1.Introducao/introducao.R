#######################################################
#######    PROGRAMAÇÃO EM R - INTRODUÇÃO      #########
#######################################################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

#####
##   ARITMÉTICA
#####

# Adição
5 + 5

# Subtração
5 - 5

# Multiplicação
3 * 5

# Divisão
(5 + 5)/2

# Exponencial
2^5

# Exponencial na base e
exp(1)       

# Módulo ou valor absoluto
abs(-10)

# Aplica a notação hierárquica de parênteses. Primeiro o que está em parênteses.
(4 + 5 ) * 7 - (36/18)^3

# Raiz Quadrada
sqrt(9)   

# Logaritmo natural ou neperiano
log(10)   

# Logaritmo base 10
log(10, base = 10) 

# Também logaritmo de base 10
log10(10)   

# Seno
sin(0.5*pi)    

# Coseno
cos(2*pi)      

# Tangente
tan(pi)      

#####
##   VARIÁVEIS
#####

# Atribuir o valor 42 para x
x <- 42

# Visualizar o valor da variável x 
x

# Atribuir valores para duas variáveis: my_apples e my_oranges
my_apples <- 5
my_oranges <- 6

# Definir uma nova variável como a soma das duas variáveis anteriores
my_fruit <- my_apples + my_oranges

# Visualizar o valor da variável my_fruit
my_fruit

#####
##   VETORES
#####

# Definindo tipos de vetores usando os dados estudados anteriormente
numeric_vector <- c(1, 10, 49)
character_vector <- c("a", "b", "c")
boolean_vector <- c(T,F,T)

# Visualizando os vetores criados
numeric_vector
character_vector
boolean_vector

# Verificando o tipo de cada vetor
class(numeric_vector)
class(character_vector)
class(boolean_vector)

# Vetor de ganhos com Poker de Segunda-feira a Sexta-feira
poker_vector <- c(140, -50, 20, -120, 240)
poker_vector

# Vetor de ganhos na roleta de Segunda-feira a Sexta-feira
roulette_vector <- c(-24, -50, 100, -350, 10)
roulette_vector

#####
##   NOMEANDO VETORES
#####

# Criando a variável days_vector com os dias da semana
days_vector <- c("Mon","Tues","Wed","Thur","Fri")

# Atribuindo os nomes dos dias aos vetores usando a variável days_fator
names(poker_vector) <- days_vector
poker_vector

names(roulette_vector) <- days_vector
roulette_vector

#####
##   OPERAÇÕES COM VETORES
#####

# Calculando o ganho total por dia nos dois jogos
total_daily <- poker_vector + roulette_vector
total_daily

# Calculando o ganho total na semana por tipo de jogo
total_poker <- sum(poker_vector)
total_roulette <- sum(roulette_vector)

# Calculando o ganho total na semama nos dois jogos
total_week <- sum(roulette_vector) + sum(poker_vector)
total_week

# Verificando se você ganhou mais no poker do que com a roleta
answer <- total_poker > total_roulette
answer

# Criar uma nova variável a partir da seleção de um valor do vetor
poker_wednesday <- poker_vector["Wed"]
poker_wednesday

poker_midweek <- poker_vector[c("Tues","Wed","Thur")]       
poker_midweek 

# Outra opção de selecionar valores de um vetor e atribuí-los a outra variável
roulette_selection_vector <- roulette_vector[2:5]
roulette_selection_vector 

# Calculando o ganho médio no meio da semana a partir da seleção de valores do vetor
average_midweek_gain <- mean(poker_vector[c("Mon","Tues","Wed")])
average_midweek_gain

# Verificando que dia da semana você ganhou no poker
selection_vector <- poker_vector > 0
selection_vector

# Selecionando os valores para os dias que você ganhou no poker
poker_winning_days <- poker_vector[selection_vector]
poker_winning_days

# Outra opção de fazer o mesmo, mas agora para a roleta
roulette_winning_days <- roulette_vector[roulette_vector > 0]
roulette_winning_days

#####
##   FATORES
#####

# Criar um vetor de gênero
gender_vector <- c("Male","Female","Female","Male","Male")

# Criar um vetor de animais
animals_vector <- c("Elephant", "Giraffe", "Donkey", "Horse")

# Criar um vetor de temperatura 
temperature_vector <- c("High", "Low", "High", "Low", "Medium")

# Declarar o vetor de gênero como um fator
factor_gender_vector <- factor(gender_vector)
factor_gender_vector

# Declarar o vetor de animais como um fator
factor_animals_vector <- factor(animals_vector)
factor_animals_vector

# Atribuir levels para o fator e label. O level define a ordem (baixa, média e alta) enquanto o label pode 
# ser entendido como um nome para cada level do fator
factor_temperature_vector <- factor(temperature_vector, order = TRUE, 
                                   levels = c("Low", "Medium", "High"), labels = c("L","M","H"))
factor_temperature_vector

#####
##   OPERAÇÕES COM FATOR
#####

# quantidade de homens e mulheres
table(factor_gender_vector)

# quantidade de animais por tipo
table(factor_animals_vector)

# quantidade de temperaturas por tipo
table(factor_temperature_vector)

#####
##   FATOR ORDENADO
#####

# Note que fatores têm um atributo que especifica seu níveis ou categorias (levels), 
# que seguem ordem alfanumérica crescente, por default. Como essa ordem é importante 
# para muitas análises, pode-se alterá-la com o argumento levels para colocar a ordem desejada.

speed_vector <- c('Fast','Slow','Slow','Fast','Ultra-fast')

# Transformar o vetor em um fator e definir a ordem das velocidades
factor_speed_vector <- factor(speed_vector, ordered = T, levels = c('Slow','Fast','Ultra-fast'))
factor_speed_vector

# Quantidade por tipo de velocidade
table(factor_speed_vector)

#####
##   MATRIZES
#####

# Gerar uma matriz com 3 linhas, preenchida por linha com os números de 1 a 9. 
# Por default os elementos são organizados por coluna na matriz, caso se deseje
# que estes sejam organizados por linha usa-se o argumento byrow = TRUE.
M <- matrix(data = 1:9, nrow = 3, ncol = 3, byrow = TRUE)

# Bilheteria Star Wars: em milhões! O primeiro elemento: US e o segundo No-US
new_hope <- c(461, 314.4)
empire_strikes <- c(290.5, 247.9)
return_jedi <- c(309.3,165.8)

# Construir a matriz usando os dados acima
star_wars_matrix <- matrix(c(new_hope, empire_strikes, return_jedi), byrow=T, nrow=3)
star_wars_matrix

#####
##   NOMEAR MATRIZES
#####

# Nomeando as linhas e colunas da matriz anterior
rownames(star_wars_matrix) <- c('A New Hope','The Empire Strikes Back','Return of the Jedi')
colnames(star_wars_matrix) <- c('US','non-US')
star_wars_matrix

#####
##   OPERAÇÕES COM MATRIZES
#####

# Dados de bilheteria da segunda trilogia 
box_office_all <- c(474.5, 552.5, 310.7, 338.7, 380.3, 468.5)
movie_names <- c("The Phantom Menace","Attack of the Clones","Revenge of the Sixth")
col_titles <- c("US","non-US")

# Matriz com os dados da segunda trilogia
star_wars_matrix2 <- matrix(box_office_all, nrow=3, byrow=TRUE, dimnames=list(movie_names,col_titles))
star_wars_matrix2

# Combinar as linhas das duas trilogias
all_wars_matrix <- rbind(star_wars_matrix, star_wars_matrix2)
all_wars_matrix

# A bilheteria total para a saga 
total_revenue_vector <- colSums(all_wars_matrix)
total_revenue_vector

# Somar para cada linha (ou filme) a bilheteria total (US e non-US)
worldwide_vector <- rowSums(all_wars_matrix)
worldwide_vector

# Calculando a média da segunda coluna
mean_non_us_all  <-  mean(star_wars_matrix[,2])
mean_non_us_all

# Calculando a média das duas primeiras linhas da segunda coluna
mean_non_us_some <- mean(star_wars_matrix[1:2,2])
mean_non_us_some

#####
##   ÁLGEBRA MATRICIAL
#####

# Matrizes a serem utilizadas
M1 <- matrix(c(2, 3, 5, 6), nrow = 2)
M2 <- matrix(c(5, 3, 8, 2), nrow = 2)
M3 <- matrix(c(2, 4, 6, 2, 0,1), nrow = 2, ncol = 3)
M4 <- matrix(c(1, 0.5, 0.3, 0.5, 1, 0.9, 0.3, 0.9, 1), nrow = 3, ncol = 3)

# Soma e subtração
soma <- M2 + M1
subtracao <- M2 - M1

# Multiplicação escalar
prod_escalar <- 42*M4

# Multiplicação matricial 
prod_matricial <- M1 %*% M3

# Matriz transposta 
transposta <- t(M3)

# Determinante de uma matriz
determinante <- det(M2)

# Inversa de uma matriz 
inversa <- solve(M1)

#####
##   DATA FRAMES 
#####

# Criando um data frame. stringsAsFactors diz se quero (TRUE) ou não (FALSE) 
# transformar as variáveis com texto em um fator
funcionarios <- data.frame(nome = c("João", "Maria", "José"),
                          sexo = c("M", "F", "M"),
                          salario = c(1000, 1200, 1300),
                          stringsAsFactors = FALSE)

# verificando a classe de cada coluna do data frame
str(funcionarios)

# uma matriz com os mesmos dados obrigatoriamente terá uma única classe (character)
# a função as.matrix obriga que o dado recebido seja transformado em uma matriz
as.matrix(funcionarios)

#####
##   OPERAÇÕES COM DATA FRAME 
#####

# Tudo menos a linha 1
funcionarios[-1, ]

# Apenas a primeira linha da primeira coluna
funcionarios[1, 1]

# Terceira linha das colunas "nome" e "salario"
funcionarios[3 , c("nome", "salario")]

#####
##   LISTAS 
#####

# Vetor com números de 1 a 10
my_vector <- 1:10 
my_vector

# Matriz com números de 1 até 9
my_matrix <- matrix(1:9, ncol = 3)
my_matrix

# Primeiras 10 linhas do data frame mtcars
my_df <- mtcars[1:10,]
my_df

# Construindo uma lista com os três diferentes objetos
my_list <- list(my_vector, my_matrix, my_df)
my_list

# Nomear cada elemento da lista
names(my_list) <- c("vetor","matriz","dataframe")

#####
##   OPERAÇÕES COM UMA LISTA 
#####

# Selecionar a primeira linha da primeira coluna da matriz que está na lista
my_list$matriz[1,1]

# Selecionar o primeiro valor do vetor
my_list$vetor[1]

# Selecionar 3 primeiras linhas do data frame
my_list$dataframe[1:3,]


#######################################################
#######    PROGRAMAÇÃO EM R - IMPORTAR DADOS  #########
#######################################################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

#####
##   DADOS LOCAIS - DIGITANDO
#####

# Criando um data frame com endereço de piscinas
swimming_pools <- structure(list(
  Name = structure(c(1L, 2L, 3L, 4L, 5L, 6L, 19L, 7L, 8L, 9L, 10L, 11L,
                     13L, 14L, 15L, 16L, 17L, 18L, 12L, 20L),
  .Label = c("Acacia Ridge Leisure Centre", "Bellbowrie Pool", "Carole Park",
             "Centenary Pool (inner City)", "Chermside Pool", "Colmslie Pool (Morningside)",
             "Dunlop Park Pool (Corinda)", "Fortitude Valley Pool", "Hibiscus Sports Complex (upper MtGravatt)",
             "Ithaca Pool (Paddington)", "Jindalee Pool", "Langlands Parks Pool (Stones Corner)",
             "Manly Pool", "Mt Gravatt East Aquatic Centre", "Musgrave Park Pool (South Brisbane)",
             "Newmarket Pool", "Runcorn Pool", "Sandgate Pool", "Spring Hill Baths (inner City)", 
              "Yeronga Park Pool"), class = "factor"), 
  Address = structure(c(5L, 20L, 18L, 10L, 9L, 11L, 6L, 15L, 12L, 17L, 4L, 
                        3L, 1L, 19L, 2L, 14L, 8L, 7L, 13L, 16L), 
  .Label = c("1 Fairlead Crescent, Manly", "100 Edmonstone Street, South Brisbane", "11 Yallambee Road, Jindalee", 
             "131 Caxton Street, Paddington", "1391 Beaudesert Road, Acacia Ridge", "14 Torrington Street, Springhill", 
             "231 Flinders Parade, Sandgate", "37 Bonemill Road, Runcorn", "375 Hamilton Road, Chermside", 
             "400 Gregory Terrace, Spring Hill", "400 Lytton Road, Morningside", "432 Wickham Street, Fortitude Valley",
             "5 Panitya Street, Stones Corner", "71 Alderson Stret, Newmarket", "794 Oxley Road, Corinda", "81 School Road, Yeronga", 
             "90 Klumpp Road, Upper Mount Gravatt", "Cnr Boundary Road and Waterford Road Wacol", "Cnr wecker Road and Newnham Road, Mansfield", 
             "Sugarwood Street, Bellbowrie"), class = "factor"), 
  Latitude = c(-27.58616, -27.565466, -27.607439, -27.455369, -27.385829, -27.45516, -27.459596, -27.546519, -27.4539, 
               -27.551826, -27.462262, -27.532363, -27.452285, -27.532135, -27.479777, -27.42968, -27.591561, -27.311956, 
               -27.497689, -27.520527), 
  Longitude = c(153.026354, 152.891082, 152.931511, 153.025067, 153.035109, 153.078861, 153.021548, 152.980628, 153.0368, 
                153.07354, 153.010347, 152.942691, 153.187437, 153.094289, 153.016806, 153.006206, 153.076415, 153.069098, 
                153.04867, 153.018544)), 
  .Names = c("Name", "Address", "Latitude", "Longitude"), 
  class = "data.frame", 
  row.names = c(NA, 20L))

# Exemplo de como os dados são armazenados
head(swimming_pools)

#####
##   DADOS LOCAIS - LEITURA DE UM CSV
#####

# Dados meteorológicos por hora para os aeroportos LGA, JFK e EWR
data(weather, package = "nycflights13")

# Local temporário onde os arquivos serão salvos
weather_csv <- "/cloud/project/1.Programacao_em_R/3.Carregar_Dados/weather.csv"

# Salvar os dados como um csv
readr::write_csv(x = weather, path = weather_csv)

# Leitura do arquivo csv deixando a função definir o tipo de cada coluna
read_weather_csv <- readr::read_csv(weather_csv)

# Leitura do arquivo csv especificando o tipo de cada coluna
read_weather_csv_type_cols <- readr::read_csv(weather_csv, col_types = cols(
  origin = col_character(),
  year = col_integer(),
  month = col_integer(),
  day = col_integer(),
  hour = col_integer(),
  temp = col_double(),
  dewp = col_double(),
  humid = col_double(),
  wind_dir = col_integer(),
  wind_speed = col_double(),
  wind_gust = col_double(),
  precip = col_double(),
  pressure = col_double(),
  visib = col_double(),
  time_hour = col_datetime(format = "")
))


#####
##   DADOS LOCAIS - LEITURA DE UM TXT
#####

# Local temporário onde os arquivos serão salvos
weather_txt <- "/cloud/project/1.Programacao_em_R/3.Carregar_Dados/weather.txt"

# Salvar os dados como um txt
readr::write_delim(weather, weather_txt, delim = '\t', col_names=TRUE)

# Leitura do arquivo txt deixando a função definir o tipo de cada coluna
read_weather_txt <- readr::read_delim(weather_txt, delim = "\t")

# Leitura do arquivo txt especificando o tipo de cada coluna
read_weather_txt_type_cols <- readr::read_delim(weather_txt, delim = "\t", col_types = cols(
  origin = col_character(),
  year = col_integer(),
  month = col_integer(),
  day = col_integer(),
  hour = col_integer(),
  temp = col_double(),
  dewp = col_double(),
  humid = col_double(),
  wind_dir = col_integer(),
  wind_speed = col_double(),
  wind_gust = col_double(),
  precip = col_double(),
  pressure = col_double(),
  visib = col_double(),
  time_hour = col_datetime(format = "")
))

#####
##   DADOS LOCAIS - LEITURA DE UM XLSX
#####

# Exemplo de arquivos xlsx que são armazenados no R ao instalar o pacote tidyverse
readxl::readxl_example()

# Local onde um arquivo específico da lista acima está salvo
xlsx_example <- readxl::readxl_example("datasets.xls")

# Planilhas contidas no arquivo
readxl::excel_sheets(xlsx_example)

# Fazer a leitura de uma planilha específica
read_chickwts_excel <- readxl::read_excel(xlsx_example, sheet = "chickwts") # usando o nome
read_quakes_excel <- readxl::read_excel(xlsx_example, sheet = 4)            # usando a posição



#####
##   DADOS DA INTERNET - LEITURA DE UM CSV
#####

# URL do arquivo csv
url_csv <- "https://s3.amazonaws.com/assets.datacamp.com/production/course_1478/datasets/swimming_pools.csv"

# Leitura do arquivo csv deixando a função definir o tipo de cada coluna
read_weather_csv_from_web <- readr::read_csv(url_csv)

# Leitura do arquivo csv especificando o tipo de cada coluna
read_weather_csv_from_web_type_cols <- readr::read_csv(url_csv, col_types = cols(
  Name = col_character(),
  Address = col_character(),
  Latitude = col_double(),
  Longitude = col_double()
))

#####
##   DADOS DA INTERNET - LEITURA DE UM TXT
#####

# URL do arquivo txt
url_txt <- "http://s3.amazonaws.com/assets.datacamp.com/production/course_1478/datasets/potatoes.txt"

# Leitura do arquivo txt deixando a função definir o tipo de cada coluna
read_weather_txt_from_web <- readr::read_delim(url_txt, delim = "\t")

# Leitura do arquivo csv especificando o tipo de cada coluna
read_weather_txt_from_web_type_cols <- readr::read_delim(url_txt, delim = "\t", col_types = cols(
  area = col_integer(),
  temp = col_integer(),
  size = col_integer(),
  storage = col_integer(),
  method = col_integer(),
  texture = col_double(),
  flavor = col_double(),
  moistness = col_double()
))


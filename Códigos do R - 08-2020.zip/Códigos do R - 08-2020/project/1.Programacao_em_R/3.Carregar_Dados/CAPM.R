#########################################
####    ESTIMAÇÃO DO MODELO CAPM     ####
#########################################

########
##   PACOTES NECESSÁRIOS
#####

# limpando a memória
rm(list=ls())

# carregando pacotes
library(quantmod) # cotações das ações e do Ibov
library(Quandl) # Selic BACEN
library(ggplot2) # para gerar os gráficos
library(gridExtra) # para vaios graficos juntos
library(lmtest) # testes: breusch-godfrey, breuch-pagan
library(tseries) # jarque-bera test

########
##   COLETA DE DADOS
#####

# Coleta das cotações mensais da petrobras e do ibovespa
getSymbols(c("PETR4.SA","^BVSP"),
           periodicity='monthly', 
           from='2000-01-01',
           to='2019-07-01'
)

# Coleta da taxa selic mensal
Quandl.api_key('3gMh2BSgyDSpD4qxrsaT') # set your API key = Comando necessário pra acessar o Quandl
selic <- Quandl("BCB/4390",type = 'xts', start_date = "2000-01-01", end_date = "2019-07-01") # importando a serie do selic do Bacen
selic <- Quandl("BCB/4390",type = 'xts') # importando a serie do selic do Bacen


# Checando a periodicidade dos dados da petrobras
periodicity(PETR4.SA)
periodicity(BVSP)
periodicity(selic)

# Gerando gráficos de cotações e índices
# petr4 
g1 <-  ggplot(PETR4.SA, aes(time(PETR4.SA), PETR4.SA$PETR4.SA.Adjusted)) + geom_line() +
  scale_x_date(date_labels =  "%m/%Y", date_breaks = "1 year", 
               limits=c(min(time(PETR4.SA)),max(time(PETR4.SA)))) +
  xlab("") + ylab("PETR4") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))
# ibov
g2 <- ggplot(BVSP, aes(time(BVSP), BVSP$BVSP.Adjusted)) + geom_line() +
  scale_x_date(date_labels =  "%m/%Y", date_breaks = "1 year", 
               limits=c(min(time(BVSP)),max(time(BVSP)))) +
  xlab("") + ylab("BVSP") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

# os três graficos  juntos  
grid.arrange(g1, g2, nrow = 2)

########
##   CÁLCULO DOS RETORNOS
#####


# calculando retornos mensais petr4 e ibov com base no preço ajustado
dados <- merge(monthlyReturn(PETR4.SA[,6],type='log')[-1,], 
               monthlyReturn(BVSP[,6],type="log")[-1,]
)

# juntando os dados petr4, ibov e selic
dados <- merge(dados,as.xts(selic/100),join="inner")

# renomeando as colunas
names(dados) <- c("petr4","ibov","selic")
head(dados)

# Gerando gráficos dos retornos
# petr4 
g3 <- ggplot(dados, aes(time(dados), petr4)) + geom_line() +
  scale_x_date(date_labels =  "%m/%Y", date_breaks = "1 year", limits=c(min(time(dados)),max(time(dados)))) +
  xlab("") + ylab("PETR4") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))
# ibov
g4 <- ggplot(dados, aes(time(dados), ibov)) + geom_line() +
  scale_x_date(date_labels =  "%m/%Y", date_breaks = "1 year", 
               limits=c(min(time(dados)),max(time(dados)))) +
  xlab("") + ylab("IBOV") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))
# selic
g5 <- ggplot(dados, aes(time(dados), selic)) + geom_line() +
  scale_x_date(date_labels =  "%m/%Y", date_breaks = "1 year", 
               limits=c(min(time(dados)),max(time(dados)))) +
  xlab("") + ylab("SELIC") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

# os três graficos  juntos  
grid.arrange(g3, g4, g5, nrow = 3)

# estimando o modelo de regressão do CAPM
mod1 <- lm(I(petr4 - selic) ~ I(ibov - selic), data=dados)
# mostrando os resultados
summary(mod1)

g6 <- ggplot(dados, aes(x=(ibov-selic), y=(petr4-selic))) + geom_point() + geom_smooth(method=lm, se=FALSE)
g6

########
##   ANÁLISE DOS RESÍDUOS
#####

g7 <- plot(mod1$residuals)
g8 <- plot.ts(mod1$residuals)
g9 <- hist(mod1$residuals)

# testando se os resíduos são normais
jarque.bera.test(mod1$residuals)

# testando se os resíduos da regressão estimada são homocedásticos (Breuch-Pagan)
# heteroscedasticidade
bptest(mod1)

# testando se há autocorrelação nos resíduos da regressão estimada (Breuch-Godfrey)
# autocorrelação
bgtest(mod1)


#######################################################
####    COLETAR DADOS FINANCEIROS E ECONÔMICOS     ####
#######################################################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

#####
##   DADOS DO BANCO CENTRAL
#####

# Para coletar dados do Banco Central do Brasil (BACEN) no R usamos o pacote Quandl e
# nos seguintes passos:
# 1. Acessar o site do Quandl e criar uma conta que disponibilizará uma key para usar no R
# 2. Acessar o sistema de séries temporais do BACEN (http://www.bcb.gov.br/?SERIESTEMP)
# 3. Escolher uma série temporal de interesse e seu código. 
# 4. Usar o código da série temporal abaixo: 

# Definir sua api key
Quandl.api_key('3gMh2BSgyDSpD4qxrsaT')
#Quandl.api_key('NjGc22-41R7zD_K7Pt7z')
#Quandl.api_key('xvSrAztygUphvYp9q1bs')

# Coletar o dado do IPCA. Observe que adicionamos BCB/ ao código da série temporal. Sempre usaremos BCB/ 
# para coletar dados do BACEN por meio do Quandl. Ele tem o significado de determinar de qual banco de 
# dados o Quandl deve buscar pela série que o número definido. Como padrão o Quandl coletará os dados na
# periodicidade divulgada pelo BACEN.
ipca <- Quandl('BCB/433')

# Coletar a mesma informação para um período específico
ipca <- Quandl('BCB/433', start_date = "1996-01-01", end_date = "2017-12-31")

# Coletar definindo apenas a data inicial 
ipca <- Quandl('BCB/433', start_date = "1996-01-01")

# Coletar definindo a periodicidade de interesse
# Opções: daily, weekly, monthly, quarterly, annual
ipca <- Quandl("BCB/433", collapse = "quarterly", start_date = "1996-01-01")

# Coletar fazendo alterações nos dados. Transformações nos dados permitidas pelo Quandl:
# - diff: z[t] = y[t] – y[t-1] (diferença)
# - rdiff: z[t] = (y[t] – y[t-1]) / y[t-1] (diferença %)
# - rdiff_from: z[t] = (y[latest] – y[t]) / y[t] (incremento % em relação à última observação)
# - cumul:  z[t] = y[0] + y[1] + … + y[t] (soma acumulativa)
# - normalize: z[t] = y[t] ÷ y[0] * 100 (série iniciar em 100)
ipca <- Quandl("BCB/433", transform = "diff", start_date = "1996-01-01")

# Coletar definido o tipo de dado que queremos no R
# - ts: série temporal
# - zoo: objeto zoo 
# - xts: no formato xts
# Detalhes sobre a diferença entre os tipos no link abaixo
# https://stackoverflow.com/questions/33714660/what-is-the-difference-the-zoo-object-and-ts-object-in-r
ipca <- Quandl("BCB/433", start_date = "1996-01-01", type = "ts")
ipca <- Quandl("BCB/433", start_date = "1996-01-01", type = "xts")

# Visualizar os dados usando o pacote dygraphs. Mais detalhes em
plot.ts(ipca, main = "Índice Nacional de Preços ao Consumidor-Amplo (IPCA)", ylab = "", xlab = "")
plot.xts(ipca)

#####
##   DADOS DO YAHOO FINANCE
#####

# Para coletar os dados do Yahoo Finance, precisamos dos seguintes passos:
# 1. Acessar o site do Yahoo Finance (https://finance.yahoo.com/), 
# 2. escolher uma ação de interesse e seu código. Por exemplo, a ação da 
# Vale negociada na BM&F BOVESPA que tem o código VALE3.SA. 
# 3. No R, execute o seguinte:

# A opção auto.assign define se os dados devem ser incorporados no R com o nome
# do symbol ou um nome específico (auto.assign = FALSE). No nosso caso, optamos
# pelo nome vale.
vale <- quantmod::getSymbols("VALE3.SA", src = "yahoo", auto.assign = TRUE)
na.omit(vale)

# Coletar os dados para um período específico
vale <- quantmod::getSymbols("VALE3.SA", src = "yahoo", auto.assign = TRUE, from = '2015-01-01', to = '2015-12-31')

# Coletar os dados de uma data específica até a última observação disponível sobre a ação
vale <- quantmod::getSymbols("VALE3.SA", src = "yahoo", auto.assign = TRUE, from = '2017-01-01')

# Coletar definido o tipo de dado que queremos no R
# - ts: série temporal
# - zoo: objeto zoo 
# - xts: no formato xts
# Detalhes sobre a diferença entre os tipos no link abaixo
# https://stackoverflow.com/questions/33714660/what-is-the-difference-the-zoo-object-and-ts-object-in-r
vale <- quantmod::getSymbols("VALE3.SA", src = "yahoo", auto.assign = TRUE, from = '2017-01-01', return.class = 'xts')
#vale_monthly <- quantmod::getSymbols("VALE3.SA", src = "yahoo", auto.assign = TRUE, from = '2017-01-01', return.class = 'xts', periodicity="monthly")

# Calcular o retorno diário usando o log(p_t) - log(p_t-1). 
daily_return <- PerformanceAnalytics::Return.calculate(VALE3.SA$VALE3.SA.Close, method = "log")
daily_return <- periodReturn(VALE3.SA$VALE3.SA.Close,type="log",period="daily")

# Outra opção é o retorno diário por meio da opção method = "discrete"
daily_return <- PerformanceAnalytics::Return.calculate(VALE3.SA$VALE3.SA.Close, method = "discrete")
daily_return <- periodReturn(VALE3.SA$VALE3.SA.Close,type="arithmetic",period="daily")

# Outra opção é alterar a periodicidade dos preços e retornos, neste caso tem-se o o preço e log-retorno mensal 
monthly_return <- periodReturn(VALE3.SA$VALE3.SA.Close,type="log",period="monthly")

# Visualizar a série temporal dos retornos
plot.ts(daily_return, main = "Retorno Diário da VALE3.SA", ylab = "", xlab = "")
#plot.ts(monthly_return, main = "Retorno Mensal da VALE3.SA", ylab = "", xlab = "")

# Gráfico da série temporal dos preços
plot.ts(VALE3.SA$VALE3.SA.Close, main = "Preço Diário da VALE3.SA", ylab = "", xlab = "")
#plot.ts(VALE3.SA$VALE3.SA.Close, main = "Preço Mensal da VALE3.SA", ylab = "", xlab = "")

# Colocar os dois gráficos juntos
# Mais detalhes de como combinar gráficos no R neste link (https://www.statmethods.net/advgraphs/layout.html)
# Aqui, estamos fazendo o seguinte
# 1. pedindo o R para dividir a página onde o gráfico ficará em uma matrix com 1 coluna e 2 linha
# 2. preencher nesta matriz com o número do gráfico que ficará em cada posição. Para isso, usamos
# c(1,2) dizendo para o R colocar estes dois números em uma coluna (ncol=1) e duas linhas (nrow=2),
# preenchendo por linha. Ou seja, o gráfico 1 fica na primeira linha e o gráfico 2 na segunda linha
layout(matrix(c(1,2), ncol = 1, nrow = 2, byrow = TRUE))
plot.ts(VALE3.SA$VALE3.SA.Close, main = "Preço Diário da VALE3.SA", ylab = "", xlab = "")
plot.ts(daily_return, main = "Retorno Diário da VALE3.SA", ylab = "", xlab = "")

# Estimação do Modelo CAPM
ambev <- quantmod::getSymbols("ABEV3.SA", from = '2008-01-01', return.class = 'xts')
head(ABEV3.SA)
return_ambev <- PerformanceAnalytics::Return.calculate(ABEV3.SA$ABEV3.SA.Adjusted, method = "log")
head(return_ambev)
layout(matrix(c(1,2), ncol = 1, nrow = 2, byrow = TRUE))
plot.ts(ABEV3.SA$ABEV3.SA.Adjusted, main = "Preço Diário da AMBEV3", ylab = "", xlab = "")
plot.ts(return_ambev, main = "Retorno Diário da AMBEV3", ylab = "", xlab = "")

ibovespa <- quantmod::getSymbols("^BVSP", src = "yahoo", auto.assign = TRUE, from = '2008-01-01', return.class = 'xts')
return_ibovespa <- PerformanceAnalytics::Return.calculate(BVSP$BVSP.Adjusted, method = "log")
head(return_ibovespa)
layout(matrix(c(1,2), ncol = 1, nrow = 2, byrow = TRUE))
plot.ts(BVSP$BVSP.Adjusted, main = "Índice Diário do IBOVESPA", ylab = "", xlab = "")
plot.ts(return_ibovespa, main = "Retorno Diário do IBOVESPA", ylab = "", xlab = "")

correlationTest(return_ambev,return_ibovespa,method="pearson")

CAPM <- lm (return_ambev~return_ibovespa)
summary (CAPM)
b0=CAPM.alpha(return_ambev,return_ibovespa) 
b1=CAPM.beta(return_ambev,return_ibovespa)
plot.ts(return_ibovespa,return_ambev)
abline (b0, b1)


################################
####     MODELAGEM ARMA      ###
################################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

#####
##   OPÇÕES
#####

# Definir ponto inicial para permitir replicar o exemplo. Gerar mesmos valores aleatórios
set.seed(123)

#####
##   ARMA(1,1)
#####

# Dados Simulados:
# - arima.sim: função do pacote stats que nos permite simular um modelo arima, usando:
#    - model: uma lista com as especificações ar, diff e ma do modelo com as seguintes opções:
#      - order: a ordem do modelo (no exemplo abaixo, arima(1,0,1), ou seja um arma(1,1))
#      - ar: valores para os parâmetros ar do modelo (no exemplo abaixo apenas um valor para o ar1)
#      - ma: valores para os parâmetros ma do modelo (no exemplo abaixo, apenas um valor para o ma1)
#    - n: o tamanho da série temporal a ser simulada
#    - rand.gen: a função a ser usada para gerar os resíduos do modelo. Abaixo, usamos a função
# rnorm o que torna os resíduos normalmente distribuídos. Outra alternativa, seria usar a função
# rt para resíduos distribuídos conforme uma t de Student. 
arma11 <- stats::arima.sim(model = list(order = c(2,0,2),
                                        ar = c(0.8, -0.5),
                                        ma = c(0.8, 0.5)), 
                        n = 1000, 
                        rand.gen = rnorm) +  10 # + 10 faz o papel do intercepto = 2, pois estou somando 2 na parte função dos parâmetroa ar e ma

head(arma11)
tail(arma11)

# Gráfico da série temporal.
plot.ts(arma11, type = "l", main = "ARMA(2,2) Simulado", xlab = "Tempo", ylab = "") 

# Estimação do Modelo ARMA(2,2)
model1 <- arima(arma11, order=c(2,0,2))
coeftest(model1)
names(model1)
model1$coef
model1$residuals

#####
##   FAC E FACP DA SÉRIE TEMPORAL
#####

par(mfrow=c(1,2)) 
# Função de autocorrelação
acf_arma11 <- stats::acf(arma11, na.action = na.pass, plot = FALSE, lag.max = 15)

# Gráfico da função de autocorrelação. 
plot(acf_arma11, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)

# Função de autocorrelação parcial
pacf_arma11 <- stats::pacf(arma11, na.action = na.pass, plot = FALSE, lag.max = 15)

# Gráfico da função de autocorrelação parcial. 
plot(pacf_arma11, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

par(mfrow=c(1,3)) 
acf_arma11 <- stats::acf(model1$residuals, na.action = na.pass, plot = FALSE, lag.max = 15)
plot(acf_arma11, main = "", ylab = "", xlab = "Defasagem")
pacf_arma11 <- stats::pacf(model1$residuals, na.action = na.pass, plot = FALSE, lag.max = 15)
plot(pacf_arma11, main = "", ylab = "", xlab = "Defasagem")
hist(model1$residuals)

#####
##   ESTIMAÇÃO DE TODAS AS COMBINAÇÕES USANDO MÁXIMA VEROSSIMLILHANÇA
#####

# Todas as combinações possíveis de p=0 até p=max e q=0 até q=max
pars <- expand.grid(ar = 0:2, diff = 0, ma = 0:2)
 
# Local onde os resultados de cada modelo será armazenado
modelo <- list()

# Estimar os parâmetros dos modelos usando Máxima Verossimilhança (ML)
for (i in 1:nrow(pars)) {
  modelo[[i]] <- stats::arima(x = arma11, order = unlist(pars[i, 1:3]), method = "ML")
}

modelo[[1]]
modelo[[1]]$loglik
aicarma[[1]]
modelo[[2]]
modelo[[2]]$loglik
aicarma[[2]]
...
modelo[[9]]
modelo[[9]]$loglik
aicarma[[9]]

# Obter o logaritmo da verossimilhança (valor máximo da função)
log_verossimilhanca <- list()
for (i in 1:length(modelo)) {
  log_verossimilhanca[[i]] <- modelo[[i]]$loglik
}

# Calcular o AIC
aicarma <- list()
for (i in 1:length(modelo)) {
  aicarma[[i]] <- stats::AIC(modelo[[i]])
}

# Calcular o BIC
bicarma <- list()
for (i in 1:length(modelo)) {
  bicarma[[i]] <- stats::BIC(modelo[[i]])
}

# Quantidade de parâmetros estimados por modelo
quant_paramentros <- list()
for (i in 1:length(modelo)) {
  quant_paramentros[[i]] <- length(modelo[[i]]$coef) + 1 # + 1 porque temos a variância do termo de erro 
}

# Montar a tabela com os resultados
especificacao <- paste0("ARMA",pars$ar,pars$diff,pars$ma)
tamanho_amostra <- rep(length(arma11), length(modelo))
resultado <- data.frame(especificacao, ln_verossimilhanca = unlist(log_verossimilhanca),
                        quant_paramentros = unlist(quant_paramentros),
                        tamanho_amostra, aic = unlist(aicarma), 
                        bic = unlist(bicarma))

# Mostrar a tabela de resultado
print(resultado)

# Escolher o melhor modelo
best1 <- which.min(resultado$aic)
best2 <- which.min(resultado$bic)

#####
##   PARÂMETROS ESTIMADOS PARA O MODELO COM MENOR AIC E/OU BIC
#####

# Aqui, usamos o número 5 para selecionar o modelo escolhido anteriormente. 
# Observe que o modelo ARMA(1,1) estava na linha 5 da tabela com todos os 
# demais modelos. Para gerar a tabela usamos a função stargazer do pacote stargazer
#stargazer::stargazer(modelo[[best1]], type = "text", title = "Resultado Estimação modelo ARMA(1,1)")
coeftest(modelo[[best1]])

#####
##   VERIFICAR RESÍDUOS DO MODELO COM MENOR AIC E/OU BIC
#####

par(mfrow=c(1,1)) 
# Teste de autocorrelação dos resíduos
#  - H0: resíduos são não autocorrelacionados
#  - H1: resíduos são autocorrelacionados
acf_arma11_est <- stats::acf(modelo[[best1]]$residuals, na.action = na.pass, plot = FALSE, lag.max = 15)
plot(acf_arma11_est, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC) dos Resíduos", adj = 0.5, line = 1)
Box.test(modelo[[best1]]$residuals,type="Ljung",lag=1)

# Teste de heterocedasticidade condicional
#  - H0: quadrado dos resíduos são não autocorrelacionados
#  - H1: quadrado dos resíduos são autocorrelacionados
acf_residuals = acf(modelo[[best1]]$residuals^2, na.action = na.pass, plot = FALSE, lag.max = 20)
plot(acf_residuals, main = "", ylab = "", xlab = "Defasagem")
title("FAC do quadrado dos resíduos", adj = 0.5, line = 1)
Box.test(modelo[[best1]]$residuals^2,type="Ljung",lag=1)
#archTest(modelo[[best1]]$residuals)

# Teste de Normalidade dos resíduos. As hipóteses para os dois testes são:
#  - H0: resíduos normalmente distribuídos
#  - H1: resíduos não são normalmente distribuídos
#shapiro.test(na.remove(modelo[[best1]]$residuals))
normalTest(na.remove(modelo[[best1]]$residuals), method = "sw")
#jarque.bera.test(na.remove(modelo[[best1]]$residuals))
normalTest(na.remove(modelo[[best1]]$residuals), method = "jb")
normalTest(na.remove(modelo[[best1]]$residuals), method = "ad")
normalTest(na.remove(modelo[[best1]]$residuals), method = "ks")

#####
##   PONTO DE ATENÇÃO
#####

# No momento que simulamos os dados do modelo arma(1,1) optamos pela função rnorm para gerar
# o termo de erro. Assim, estamos dizendo que a variável aleatória do termo de erro segue 
# uma normal com média 0 e variância 1 (que é o comportamento default da função rnorm).
# Caso optássemos por outra distribuição de probabilidade (como por exemplo, a t de Student),
# estamos assumindo que o termo de erro segue tal distribuição e neste caso, o teste para 
# verificar se os resíduos obtidos após o processo de estimação deve ser alterado (por exemplo,
# o teste Kolmogorov-Smirnov)

#####
##   Se os resíduos são ruído branco, obtem-se as previsões.
#####

# Previsão do valor médio condicional esperado e respectivo desvio
# - object: o modelo escolhido anteriormente
# - level: o intervalo de confiança (abaixo, 80%)
# - h: o horizonte de previsão
forecast::forecast(object = modelo[[best1]], level = 95, h = 2)

# gráfico da previsão
plot(forecast::forecast(object = modelo[[best1]], level = 95, h = 2))

# http://faculty.chicagobooth.edu/ruey.tsay/teaching/bs41202/sp2017/IntroPackages.pdf
# http://www.unstarched.net/r-examples/rugarch/a-short-introduction-to-the-rugarch-package/



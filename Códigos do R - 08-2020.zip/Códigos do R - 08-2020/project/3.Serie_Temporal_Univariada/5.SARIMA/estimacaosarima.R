################################
####     MODELO SARIMA     #####
################################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

##########################################
####    PASSAGENS AÉREAS - VENDAS     ####
##########################################

#####
##   1: Visualizar os dados para identificar observações fora do padrão (outliers ou dados faltantes), examinar se existe tendência e/ou sazonalidade por meio de gráficos específicos
#####

# Série temporal que registra o total de passageiros internacionais (em milhares) da companhia aérea (Pan Am) 
# no período de janeiro de 1949 a dezembro 1960, nos EUA.
air_passengers <- stats::ts(datasets::AirPassengers, start = c(1949, 1), frequency = 12)

# Gráfico da série temporal
par(mfrow=c(1,1)) 
plot(air_passengers, xlab = "Ano", ylab = "Quantidade", main = "Passagens Aéreas Vendidas pela Pan Am nos EUA")

# Caso fosse necessário diminuir o impacto de outliers ou dados faltantes nos dados, uma alternativa é usar 
# uma transformação nos mesmos. Abaixo, mostramos como isso poderia ser feito para a nossa ação, lembrando 
# que continuamos com os dados sem transformação e este é apenas um exemplo
# Aqui, usamos a função tsclean do pacote forecast para substituir outliers da série. 
# A função tem as seguintes opções
# - x: série temporal que será tratada
# - replace.missing: TRUE ou FALSE para substituir NA por meio da interpolação entre valores antes e após o NA
# - lambda: parâmetro para a transformação de Box-Cox. Mais detalhes em http://www.portalaction.com.br/manual-estatistica-basica/transformacao-de-dados
air_passengers_clean <- forecast::tsclean(x = air_passengers, replace.missing = TRUE)

# Examinar a existência de tendência e/ou sazonalidade nos dados
decomp <- stats::stl(air_passengers, "periodic")
colnames(decomp$time.series) = c("sazonalidade","tendência","restante")
plot(decomp)


#####
##   2: Se necessário, transformar os dados para estabilizar a variância (logaritmo dos dados, variação ou retorno, por exemplo)
#####

# Para estabilizar a variância vamos aplicar o logaritmo nos dados 
log_air_passengers <- (log(air_passengers))

# Gráfico do logaritmo das vendas de passagens aéreas. Observe que antes os dados oscilavam de 100 
# até 600 e agora oscilam de em torno de 4 até 6.5
plot(log_air_passengers, xlab = "Ano", ylab = "Log da quantidade", main = "Passagens Aéreas Vendidas pela Pan Am nos EUA")

par(mfrow=c(2,1)) 
plot(air_passengers, xlab = "Ano", ylab = "Quantidade", main = "Passagens Aéreas Vendidas pela Pan Am nos EUA")
plot(log_air_passengers, xlab = "Ano", ylab = "Log da quantidade", main = "Passagens Aéreas Vendidas pela Pan Am nos EUA")


#####
##   3: Testar se os dados são estacionários. Caso tenha raiz unitária é preciso diferenciar os dados até se tornarem estacionários. Para isso, testa-se novamente se a série diferenciada se tornou estacionária.
#####

# Aqui, usamos a função adfTest do pacote fUnitRoots para testar se há raiz unitária
# na série temporal avaliada. Como observamos no gráfico da série, há tendência
# nos dados e assim o teste verificará se a série se comporta como um passeio aleatório
# com drift. Isto é possível por meio da opção type que tem as seguintes alternativas:
# - nc: for a regression with no intercept (constant) nor time trend (passeio aleatório)
# - c: for a regression with an intercept (constant) but no time trend (passeio aleatório com drift)
# - ct: for a regression with an intercept (constant) and a time trend (passeio aleatório com constante e tendência)
# Além disso, definimos que no máximo duas defasagens da série devem ser usadas como
# variáveis explicativas da regressão do teste. As hipóteses do teste são:
# - H0: raiz unitária (passeio aleatório com drift)
# - H1: sem raiz unitária (não é um passeio aleatório com drift)
unitRootnc_air_passengers <- fUnitRoots::adfTest(log_air_passengers, lags =12, type = c("nc"))
print(unitRootnc_air_passengers)

unitRootc_air_passengers <- fUnitRoots::adfTest(log_air_passengers, lags = 12, type = c("c"))
print(unitRootc_air_passengers)

unitRootct_air_passengers <- fUnitRoots::adfTest(log_air_passengers, lags = 12, type = c("ct"))
print(unitRootct_air_passengers)

# Como resultado do teste temos um p-valor elevado, indicando que não rejeitamos a hipótese nula de
# presença de raiz unitária ao nível de 5% de significância. Assim, a série apresenta raiz unitária 
# e precisamos aplicar diferenciação para torná-la estacionária. Como temos tendência e sazonalidade, 
# o ideal é aplicar a primeira diferença para retirar a tendência e após isso, a diferenciação sazonal
# para retirar a sazonalidade. 
air_passengers_diff <- timeSeries::diff(timeSeries::diff(log_air_passengers, lag = 1, differences = 1), lag = 12, differences = 1)

#####
##   4: Examinar as funções de autocorrelação parcial (FAC) e autocorrelação parcial (FACP) para determinar as ordens máximas P e Q para os componentes AR e MA tanto da parte regular quanto da parte sazonal da série estacionária:
#####

# termos não sazonais: 
#   - examine as primeiras defasagens (1,2,3,..) da FAC e FACP. 
#   - mantemos o mesmo padrão já estudado, ou seja, a FAC define termos MA e a FACP termos AR
# termos sazonais: 
#   - examine padrões em defasagens que são múltiplas da periodicidade da série. 
#   - por exemplo, para dados mensais, verifique nas defasagens 12, 24, 36 (provavelmente será preciso verificar as primeiras duas ou três defasagens múltiplas da periodicidade). 
#   - avalie a FAC e FACP nas defasagens sazonais da mesma forma que você fez nas defasagens não sazonais

# Calcular a FAC
acf_air_passengers_diff <- stats::acf(air_passengers_diff, plot = FALSE, na.action = na.pass, lag.max = 24)

# Calcular a FACP 
pacf_passengers_diff <- stats::pacf(air_passengers_diff, plot = FALSE, na.action = na.pass, lag.max = 24)

# Gráfico da FAC e FACP.
plot(acf_air_passengers_diff, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
plot(pacf_passengers_diff, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

#####
##   5: Estimar todas as combinações para p, d e q. Aqui, d será fixo e igual ao número de vezes necessárias para tornar a série original estacionáira. Se não foi preciso diferenciar a série, d=0
#####

# Todas as combinações possíveis de p=0 até p=max e q=0 até q=max para a parte não sazonal e P=0 até P=max e Q=0 até Q=max para a parte sazonal
pars_air_passengers <- expand.grid(ar = 0:1, diff = 1, ma = 0:1, ars = 0:1, diffs = 1, mas = 0:1)

# Local onde os resultados de cada modelo será armazenado
modelo_air_passengers <- list()

# Estimar os parâmetros dos modelos usando Máxima Verossimilhança (ML). Por default, a função arima
# usa a hipótese de que o termo de erro dos modelos arima segue uma distribuição Normal
for (i in 1:nrow(pars_air_passengers)) {
  modelo_air_passengers[[i]] <- arima(x = log_air_passengers, order = unlist(pars_air_passengers[i, 1:3]), 
                                      seasonal = list(order = unlist(pars_air_passengers[i,4:6]), period = 12), method = "ML")
}

# Obter o logaritmo da verossimilhança (valor máximo da função)
log_verossimilhanca_air_passengers <- list()
for (i in 1:length(modelo_air_passengers)) {
  log_verossimilhanca_air_passengers[[i]] <- modelo_air_passengers[[i]]$loglik
}

# Calcular o AIC
aicsarima_air_passengers <- list()
for (i in 1:length(modelo_air_passengers)) {
  aicsarima_air_passengers[[i]] <- stats::AIC(modelo_air_passengers[[i]])
}

# Calcular o BIC
bicsarima_air_passengers <- list()
for (i in 1:length(modelo_air_passengers)) {
  bicsarima_air_passengers[[i]] <- stats::BIC(modelo_air_passengers[[i]])
}

# Quantidade de parâmetros estimados por modelo
quant_paramentros_air_passengers <- list()
for (i in 1:length(modelo_air_passengers)) {
  quant_paramentros_air_passengers[[i]] <- length(modelo_air_passengers[[i]]$coef)+1 # +1 porque temos a variância do termo de erro 
}

# Montar a tabela com os resultados
especificacao_air_passengers <- paste0("SARIMA",pars_air_passengers$ar, pars_air_passengers$diff, pars_air_passengers$ma, pars_air_passengers$ars, pars_air_passengers$diffs, pars_air_passengers$mas)
tamanho_amostra_air_passengers <- rep(length(log_air_passengers), length(modelo_air_passengers))
resultado_air_passengers <- data.frame(especificacao_air_passengers, 
                                       ln_verossimilhanca = unlist(log_verossimilhanca_air_passengers),
                                       quant_paramentros_air_passengers = unlist(quant_paramentros_air_passengers), 
                                       tamanho_amostra_air_passengers, 
                                       aic = unlist(aicsarima_air_passengers), 
                                       bic = unlist(bicsarima_air_passengers))

# Mostrar a tabela de resultado
print(resultado_air_passengers)


#####
##   6: Escolher dentre todos os modelos estimados no passo anterior, o modelo com menor AIC e/ou BIC.
#####

# Modelo com menor AIC e/ou BIC
which.min(resultado_air_passengers$aic)
which.min(resultado_air_passengers$bic)

# Parâmetros estimados do modelo com menor AIC e/ou BIC
# Aqui, usamos o número 11 para selecionar o modelo escolhido anteriormente. 
# Observe que o modelo SARIMA(0,1,1)(0,1,1)12 estava na linha 11 da tabela com todos os 
# demais modelos. 
print(summary(modelo_air_passengers[[11]]))

coeftest(modelo_air_passengers[[11]])

#####
##   7: Examinar se os resíduos se comportam como ruído branco. Caso contrário, retornar ao passo 3 ou 4.
#####

# Teste de autocorrelação dos resíduos
#  - H0: resíduos são não autocorrelacionados
#  - H1: resíduos são autocorrelacionados
acf_sarima_est <- stats::acf(modelo_air_passengers[[11]]$residuals, na.action = na.pass, plot = FALSE, lag.max = 15)
plot(acf_sarima_est, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC) dos Resíduos do SARIMA(0,1,1)(0,1,1)12", adj = 0.5, line = 1)
Box.test(modelo_air_passengers[[11]]$residuals,type="Ljung",lag=1)

# Teste de heterocedasticidade condicional
#  - H0: quadrado dos resíduos são não autocorrelacionados
#  - H1: quadrado dos resíduos são autocorrelacionados
acf_sarima_square <- acf(modelo_air_passengers[[11]]$residuals^2, na.action = na.pass, plot = FALSE, lag.max = 20)
plot(acf_sarima_square, main = "", ylab = "", xlab = "Defasagem")
title("FAC do quadrado dos resíduos do SARIMA(0,1,1)(0,1,1)12", adj = 0.5, line = 1)
Box.test(modelo_air_passengers[[11]]$residuals^2,type="Ljung",lag=1)
#archTest(modelo_air_passengers[[11]]$residuals)

# Teste de Normalidade dos resíduos. As hipóteses para os dois testes são:
#  - H0: resíduos normalmente distribuídos
#  - H1: resíduos não são normalmente distribuídos
shapiro.test(na.remove(modelo_air_passengers[[11]]$residuals))
jarque.bera.test(na.remove(modelo_air_passengers[[11]]$residuals))

# Gráfico do valores estimados para a série temporal e seus verdadeiros valores
fitted_air_passengers <- stats::fitted(modelo_air_passengers[[11]])
plot(fitted_air_passengers, type = "l", lty = 1, col = 4)
lines(log_air_passengers, type = "l", lty = 1, col = 2)
legend("topleft", legend = c("Ajustado", "Real"), col = c(1,2), lty = c(1,3))

#####
##   8: Uma vez que os resíduos são ruído branco, obter as previsões.
#####

# Previsão do valor médio condicional esperado e respectivo desvio
# - object: o modelo escolhido anteriormente
# - level: o intervalo de confiança (abaixo, 80%)
# - h: o horizonte de previsão
forecast::forecast(object = modelo_air_passengers[[11]], h = 12, level = 0.95)

# gráfico da previsão
plot(forecast::forecast(object = modelo_air_passengers[[11]], h = 12, level = 0.95))


################################
####     MODELO SARIMA     #####
################################

#####
##   PACOTES NECESSÁRIOS
#####

source("/cloud/project/install_and_load_packages.R")

##########################################
####  SIMULAÇÃO DE MODELOS SARIMA     ####
##########################################

#####
##   1o MODELO SIMULADO 
#####

# Modelo SARIMA (0,0,1)(0,0,1)[12]     
set.seed(123)
TS_sarima <- stats::arima.sim(model = list(order = c(0,0,12),
                                           ma = c(0.5, rep(0,10), 0.4)), 
                              n = 1000, 
                              rand.gen = rnorm)

# Comportamento da série temporal.
plot.ts(TS_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

#####
##   2o MODELO SIMULADO 
#####

# Modelo SARIMA (1,0,0)(1,0,0)[12]     
set.seed(123)
TS_sarima <- stats::arima.sim(model = list(order = c(12,0,0),
                                        ar = c(0.5, rep(0,10), 0.4)), 
                           n = 1000, 
                           rand.gen = rnorm)

# Comportamento da série temporal.
plot.ts(TS_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

#####
##   3o MODELO SIMULADO E ESTIMADO 
#####

# Modelo SARIMA (0,1,0)(1,0,0)[12]     
set.seed(123)
model <- Arima(ts(rnorm(200),freq=12), order=c(0,1,0), seasonal=c(1,0,0),
               fixed=c(Phi=0.6))
TS_sarima <- simulate(model, nsim=200)

# Comportamento da série temporal.
plot.ts(TS_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Comportamento da série temporal com 1 diferença.
DIF_sarima <- diff(TS_sarima)
plot.ts(DIF_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(DIF_sarima, na.action = na.pass, plot = FALSE, lag.max = 96)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(DIF_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Comportamento da série temporal  com 1 diferença sazonal após 1 diferença.
DIFS_sarima <- diff(DIF_sarima, lag = 12)
plot.ts(DIFS_sarima, type = "l", main = "Modelo  Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(DIFS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(DIFS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Estimação do Modelo SARIMA
# Modelo SARIMA (0,1,0)(1,0,0)[12]     
fit <- Arima(TS_sarima, order=c(0,1,0), seasonal=list(order=c(1,0,0), period=12))
coeftest(fit)
Box.test(fit$residuals,type="Ljung",lag=1)
Box.test(fit$residuals^2,type="Ljung",lag=1)
normalTest(fit$residuals, method = "jb")
print(aic <- stats::AIC(fit))

# Modelo INCORRETOS     
fit <- Arima(TS_sarima, order=c(1,1,0), seasonal=list(order=c(1,0,1), period=12))
coeftest(fit)

fit <- Arima(TS_sarima, order=c(0,1,1), seasonal=list(order=c(1,0,1), period=12))
coeftest(fit)

fit <- Arima(TS_sarima, order=c(1,1,1), seasonal=list(order=c(1,0,0), period=12))
coeftest(fit)
Box.test(fit$residuals,type="Ljung",lag=1)
Box.test(fit$residuals^2,type="Ljung",lag=1)
normalTest(fit$residuals, method = "jb")
print(aic <- stats::AIC(fit))

fit <- Arima(TS_sarima, order=c(0,1,0), seasonal=list(order=c(0,0,1), period=12))
coeftest(fit)
Box.test(fit$residuals,type="Ljung",lag=1)
Box.test(fit$residuals^2,type="Ljung",lag=1)
normalTest(fit$residuals, method = "jb")
print(aic <- stats::AIC(fit))

#####
##   4o MODELO SIMULADO E ESTIMADO 
#####

# Modelo SARIMA (1,1,0)(1,1,0)[12]     
set.seed(123)
model <- Arima(ts(rnorm(200),freq=12), order=c(1,1,0), seasonal=c(1,1,0),
               fixed=c(phi=0.8, Phi=0.6))
TS_sarima <- simulate(model, nsim=200)

# Comportamento da série temporal.
plot.ts(TS_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Comportamento da série temporal com 1 diferença.
DIF_sarima <- diff(TS_sarima)
plot.ts(DIF_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(DIF_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(DIF_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Comportamento da série temporal  com 1 diferença sazonal após 1 diferença.
DIFS_sarima <- diff(DIF_sarima, lag = 12)
plot.ts(DIFS_sarima, type = "l", main = "Modelo  Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(DIFS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(DIFS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Estimação do Modelo SARIMA
# Modelo SARIMA (1,1,0)(1,1,0)[12]     
fit <- Arima(TS_sarima, order=c(1,1,0), seasonal=list(order=c(1,1,0), period=12))
coeftest(fit)
Box.test(fit$residuals,type="Ljung",lag=1)
Box.test(fit$residuals^2,type="Ljung",lag=1)
normalTest(fit$residuals, method = "jb")
print(aic <- stats::AIC(fit))

# Modelo INCORRETOS     
fit <- Arima(TS_sarima, order=c(1,1,1), seasonal=list(order=c(1,1,0), period=12))
coeftest(fit)
fit <- Arima(TS_sarima, order=c(1,1,0), seasonal=list(order=c(1,1,1), period=12))
coeftest(fit)

#####
##   5o MODELO SIMULADO E ESTIMADO 
#####

# Modelo SARIMA (1,1,1)(1,1,1)[12]     
set.seed(123)
model <- Arima(ts(rnorm(200),freq=12), order=c(1,1,1), seasonal=c(1,1,1),
               fixed=c(phi=0.8, theta=0.5, Phi=0.6, Theta=0.8))
TS_sarima <- simulate(model, nsim=200)

# Comportamento da série temporal.
plot.ts(TS_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(TS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Comportamento da série temporal com 1 diferença.
DIF_sarima <- diff(TS_sarima)
plot.ts(DIF_sarima, type = "l", main = "Modelo Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(DIF_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(DIF_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Comportamento da série temporal  com 1 diferença sazonal após 1 diferença.
DIFS_sarima <- diff(DIF_sarima, lag = 12)
plot.ts(DIFS_sarima, type = "l", main = "Modelo  Simulado", xlab = "Tempo", ylab = "") 
acf_sarima <- stats::acf(DIFS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(acf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
pacf_sarima <- stats::pacf(DIFS_sarima, na.action = na.pass, plot = FALSE, lag.max = 48)
plot(pacf_sarima, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

# Estimação do Modelo SARIMA

# Modelo SARIMA (1,1,1)(1,1,1)[12]     
fit <- Arima(TS_sarima, order=c(1,1,1), seasonal=list(order=c(1,1,1), period=12))
coeftest(fit)
Box.test(fit$residuals,type="Ljung",lag=1)
Box.test(fit$residuals^2,type="Ljung",lag=1)
normalTest(fit$residuals, method = "jb")
print(aic <- stats::AIC(fit))

# Modelo INCORRETOS     
fit <- Arima(TS_sarima, order=c(1,1,1), seasonal=list(order=c(1,1,0), period=12))
coeftest(fit)
Box.test(fit$residuals,type="Ljung",lag=1)
Box.test(fit$residuals^2,type="Ljung",lag=1)
normalTest(fit$residuals, method = "jb")
print(aic <- stats::AIC(fit))

fit <- Arima(TS_sarima, order=c(1,1,0), seasonal=list(order=c(1,1,1), period=12))
coeftest(fit)
Box.test(fit$residuals,type="Ljung",lag=1)
Box.test(fit$residuals^2,type="Ljung",lag=1)
normalTest(fit$residuals, method = "jb")
print(aic <- stats::AIC(fit))


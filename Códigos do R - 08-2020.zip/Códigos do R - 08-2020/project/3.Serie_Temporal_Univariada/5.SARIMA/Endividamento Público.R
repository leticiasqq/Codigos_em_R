###################################################
######    INSTALAR E/OU CARREGAR PACOTES     ######
###################################################

source("/cloud/project/install_and_load_packages.R")


#########################################
######    IMPORTAÇÃO DOS DADOS     ######
#########################################

### Definir sua api key
Quandl.api_key('Y8aa--5_51qwB14keK3B')

### Coletar o dado do ENDIVIDAMENTO PUBLICO.
#DivGF <- Quandl('BCB/4504')

DivGFam <- Quandl('BCB/4504', type = "ts")

## Coletar definindo a periodicidade de interesse (anual)
#DivGFaa <- Quandl('BCB/4504', collapse = "annual", type = "ts")

# Visualizar os dados usando o pacote dygraphs.
dygraphs::dygraph(DivGFam, main = "Dívida Líquida do Setor Público (% PIB) - Total - Governo Federal") %>% dyRangeSelector()

DivGF_dif01 <- Quandl("BCB/4504", transform = "rdiff", type = "ts")

dygraphs::dygraph(DivGF_dif01, main = "Dívida Líquida do Setor Público (% PIB) - Total - Governo Federal") %>% dyRangeSelector()


#########################################
###### MODELO PARA O NÍVEL DA SÉRIE ##### 
#########################################

#####
##   1: Visualizar os dados para identificar observações fora do padrão (outliers ou dados faltantes), examinar se existe tendência e/ou sazonalidade por meio de gráficos específicos
#####

# Série temporal que indica o endividamento do GF em % do PIB

#DivGFam <- Quandl('BCB/4504', type = "ts")

# Gráfico da série temporal
par(mfrow=c(2,1)) 
plot(DivGFam, xlab = "Ano", ylab = "% do PIB", main = "Endividamento G.F.")
monthplot(DivGFam,xlab = "Mês", ylab = "% do PIB")

# Examinar a existência de tendência e/ou sazonalidade nos dados
par(mfrow=c(1,1)) 
decomp <- stats::stl(DivGFam, "periodic")
colnames(decomp$time.series) = c("sazonalidade","tendência","restante")
plot(decomp)

#####
##   2: Se necessário, transformar os dados para estabilizar a variância (logaritmo dos dados, variação ou retorno, por exemplo)
#####

# Para estabilizar a variância vamos aplicar o logaritmo nos dados 

log_DivGFam <- (log(DivGFam))
par(mfrow=c(2,1)) 
plot(DivGFam, xlab = "Ano", ylab = "Log da dívida", main = "Endividamento G.F.")
plot(log_DivGFam, xlab = "Ano", ylab = "Log da dívida", main = "Endividamento G.F.")

#####
##   3: Testar se os dados são estacionários. Caso tenha raiz unitária é preciso diferenciar os dados até se tornarem estacionários. Para isso, testa-se novamente se a série diferenciada se tornou estacionária.
#####

# - H0: raiz unitária (passeio aleatório)
# - H1: sem raiz unitária (não é um passeio aleatório)
unitRootnc_DivGFam <- fUnitRoots::adfTest(DivGFam, lags =12, type = c("nc"))
print(unitRootnc_DivGFam)

#Não rejeito H0 -> não estacionário

# Como resultado do teste temos um p-valor elevado, indicando que não rejeitamos a hipótese nula de
# presença de raiz unitária ao nível de 5% de significância. Assim, a série apresenta raiz unitária 
# e precisamos aplicar diferenciação para torná-la estacionária.

DivGFam_diff <- timeSeries::diff(timeSeries::diff(DivGFam, lag = 1, differences = 1), lag = 12, differences = 1)
par(mfrow=c(1,1)) 
plot(DivGFam_diff)
monthplot(DivGFam_diff)

# - H0: raiz unitária (passeio aleatório)
# - H1: sem raiz unitária (não é um passeio aleatório)
unitRootnc_DivGFam_diff <- fUnitRoots::adfTest(DivGFam_diff, lags =12, type = c("nc"))
print(unitRootnc_DivGFam_diff)

#Rejita H0 -> estacionário

#####
##   4: Examinar as funções de autocorrelação parcial (FAC) e autocorrelação parcial (FACP) para determinar as ordens máximas P e Q para os componentes AR e MA tanto da parte regular quanto da parte sazonal da série estacionária:
#####

##Sem a diferença
# Calcular a FAC
acf_DivGFam <- stats::acf(DivGFam, plot = FALSE, na.action = na.pass, lag.max = 24)

# Calcular a FACP 
pacf_DivGFam <- stats::pacf(DivGFam, plot = FALSE, na.action = na.pass, lag.max = 24)

# Gráfico da FAC e FACP.
plot(acf_DivGFam, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
plot(pacf_DivGFam, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)

##Com a diferença
# Calcular a FAC 
acf_DivGFam <- stats::acf(DivGFam_diff, plot = FALSE, na.action = na.pass, lag.max = 36)

# Calcular a FACP 
pacf_DivGFam <- stats::pacf(DivGFam_diff, plot = FALSE, na.action = na.pass, lag.max = 36)

# Gráfico da FAC e FACP.
plot(acf_DivGFam, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC)", adj = 0.5, line = 1)
plot(pacf_DivGFam, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação Parcial (FACP)", adj = 0.5, line = 1)


#####
##   5: Estimar todas as combinações para p, d e q. Aqui, d será fixo e igual ao número de vezes necessárias para tornar a série original estacionáira. Se não foi preciso diferenciar a série, d=0
#####

# Todas as combinações possíveis de p=0 até p=max e q=0 até q=max para a parte não sazonal e P=0 até P=max e Q=0 até Q=max para a parte sazonal
pars_DivGFam <- expand.grid(ar = 0:1, diff = 1, ma = 0:1, ars = 0:1, diffs = 0:1, mas = 0:1)

# Local onde os resultados de cada modelo será armazenado
modelo_DivGFam <- list()

# Estimar os parâmetros dos modelos usando Máxima Verossimilhança (ML). Por default, a função arima
# usa a hipótese de que o termo de erro dos modelos arima segue uma distribuição Normal
for (i in 1:nrow(pars_DivGFam)) {
  modelo_DivGFam[[i]] <- arima(x = DivGFam, order = unlist(pars_DivGFam[i, 1:3]), 
                                   seasonal = list(order = unlist(pars_DivGFam[i,4:6]), period = 12), method = "ML")
}

# Obter o logaritmo da verossimilhança (valor máximo da função)
log_verossimilhanca_DivGFam <- list()
for (i in 1:length(modelo_DivGFam)) {
  log_verossimilhanca_DivGFam[[i]] <- modelo_DivGFam[[i]]$loglik
}

# Calcular o AIC
aicsarima_DivGFam <- list()
for (i in 1:length(modelo_DivGFam)) {
  aicsarima_DivGFam[[i]] <- stats::AIC(modelo_DivGFam[[i]])
}

# Calcular o BIC
bicsarima_DivGFam <- list()
for (i in 1:length(modelo_DivGFam)) {
  bicsarima_DivGFam[[i]] <- stats::BIC(modelo_DivGFam[[i]])
}

# Quantidade de parâmetros estimados por modelo
quant_paramentros_DivGFam <- list()
for (i in 1:length(modelo_DivGFam)) {
  quant_paramentros_DivGFam[[i]] <- length(modelo_DivGFam[[i]]$coef)+1 # +1 porque temos a variância do termo de erro 
}

# Montar a tabela com os resultados
especificacao_DivGFam <- paste0("SARIMA",pars_DivGFam$ar, pars_DivGFam$diff, pars_DivGFam$ma, pars_DivGFam$ars, pars_DivGFam$diffs, pars_DivGFam$mas)
tamanho_amostra_DivGFam <- rep(length(DivGFam), length(modelo_DivGFam))
resultado_DivGFam <- data.frame(especificacao_DivGFam, 
                                    ln_verossimilhanca = unlist(log_verossimilhanca_DivGFam),
                                    quant_paramentros_DivGFam = unlist(quant_paramentros_DivGFam), 
                                    tamanho_amostra_DivGFam, 
                                    aic = unlist(aicsarima_DivGFam), 
                                    bic = unlist(bicsarima_DivGFam))

# Mostrar a tabela de resultado
print(resultado_DivGFam)

#####
##   6: Escolher dentre todos os modelos estimados no passo anterior, o modelo com menor AIC e/ou BIC.
#####

# Modelo com menor AIC e/ou BIC
best <- which.min(resultado_DivGFam$aic)
best1 <- which.min(resultado_DivGFam$bic)

# Parâmetros estimados do modelo com menor AIC e/ou BIC
# Aqui, usamos o número 28 para selecionar o modelo escolhido anteriormente. 
# Observe que o modelo SARIMA(1,1,1)(0,1,1)12 estava na linha 28 da tabela com todos os 
# demais modelos. 
print(summary(modelo_DivGFam[[best]]))

coeftest(modelo_DivGFam[[best]])

#####**
##   7: Examinar se os resíduos se comportam como ruído branco. Caso contrário, retornar ao passo 3 ou 4.
#####

# Teste de autocorrelação dos resíduos
#  - H0: resíduos são não autocorrelacionados
#  - H1: resíduos são autocorrelacionados
acf_sarima_est <- stats::acf(modelo_DivGFam[[best]]$residuals, na.action = na.pass, plot = FALSE, lag.max = 15)
par(mfrow=c(1,1)) 
plot(acf_sarima_est, main = "", ylab = "", xlab = "Defasagem")
title("Função de Autocorrelação (FAC) dos Resíduos do SARIMA(1,1,1)(0,1,1)12", adj = 0.5, line = 1)
Box.test(modelo_DivGFam[[best]]$residuals,type="Ljung",lag=1)

# Teste de heterocedasticidade condicional
#  - H0: quadrado dos resíduos são não autocorrelacionados
#  - H1: quadrado dos resíduos são autocorrelacionados
acf_sarima_square <- acf(modelo_DivGFam[[best]]$residuals^2, na.action = na.pass, plot = FALSE, lag.max = 20)
plot(acf_sarima_square, main = "", ylab = "", xlab = "Defasagem")
title("FAC do quadrado dos resíduos do SARIMA(1,1,1)(0,1,1)12", adj = 0.5, line = 1)
Box.test(modelo_DivGFam[[best]]$residuals^2,type="Ljung",lag=1)
#archTest(modelo_air_passengers[[12]]$residuals)

# Teste de Normalidade dos resíduos. As hipóteses para os dois testes são:
#  - H0: resíduos normalmente distribuídos
#  - H1: resíduos não são normalmente distribuídos
shapiro.test(na.remove(modelo_DivGFam[[best]]$residuals))
jarque.bera.test(na.remove(modelo_DivGFam[[best]]$residuals))
hist(modelo_DivGFam[[best]]$residuals)

# Gráfico do valores estimados para a série temporal e seus verdadeiros valores
fitted_DivGFam <- stats::fitted(modelo_DivGFam[[best]])
plot(fitted_DivGFam, type = "l", lty = 3, col = 4)
lines(DivGFam, type = "l", lty = 1, col = 2)
legend("topleft", legend = c("Real", "Ajustado"), col = c(1,2), lty = c(1,3))

#####
##   8: Uma vez que os resíduos são ruído branco, obter as previsões.
#####
# Previsão do valor médio condicional esperado e respectivo desvio
# - object: o modelo escolhido anteriormente
# - level: o intervalo de confiança (abaixo, 95%)
# - h: o horizonte de previsão
# install.packages('forecast', dependencies = TRUE)
forecast::forecast(object = modelo_DivGFam[[best]], h = 12, level = 0.95)

# gráfico da previsão
plot(forecast::forecast(object = modelo_DivGFam[[best]], h = 12, level = 0.95))

install.packages('fGarch')
library('fGarch')

plot(DivGFam_diff)

#############################################
###### MODELO PARA A VARIÂNCIA DA SÉRIE ##### 
#############################################

# APARCH(1,1) - specify omega/alpha/beta
fit 	= garchFit( ~ aparch(1, 1), data = DivGFam_diff, cond.dist = c("norm"), 
                 algorithm = c("nlminb+nm"))

# Previsão do retorno esperado e variância esperada
grafico_final <- fGarch::predict(fit, n.ahead = 12)

#OBS: Des-Diferenciar os valores finais para plotar OU Tentar incorporar no principal#


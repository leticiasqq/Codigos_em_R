########################################
####    ANÁLISE PROF. GUILHERME     ####
########################################


source("/cloud/project/install_and_load_packages.R")
#library(readxl)
Dados <- read_excel("Regressões_4xTeam.xlsx")
head(Dados)

#### Modelos para 1km em PISTA

Y_Pista <- Dados$`Y_1K-Pista`

Modelo_01 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`Massa C (kg)` 
                + Dados$`Altura (cm)`)
summary(Modelo_01)

Modelo_02 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`Massa C (kg)` 
                + Dados$`Altura (cm)` + Dados$`IMC(k/cm2)`)
summary(Modelo_02)

Modelo_03 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`IMC(k/cm2)`)
summary(Modelo_03)

Modelo_04 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Salto-Queda` )
summary(Modelo_04)

Modelo_05 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Soma 3 Saltos` )
summary(Modelo_05)

Modelo_06 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Soma 7 DC`)
summary(Modelo_06)

correlationTest(Dados$`Soma 7 DC`, Dados$Potência)
correlationTest(Dados$`Soma 7 DC`, Dados$Força)

Modelo_07 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo  + Dados$`IMC(k/cm2)` + Dados$Potência)
summary(Modelo_07)

Modelo_08 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo  + Dados$`IMC(k/cm2)` + Dados$Força)
summary(Modelo_08)

Modelo_09 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo  + Dados$`Soma 7 DC` + Dados$Potência)
summary(Modelo_09)

Modelo_10 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo  + Dados$`Soma 7 DC` + Dados$Força)
summary(Modelo_10)

Modelo_11 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`Massa C (kg)`
                + Dados$`Soma 7 DC`)
summary(Modelo_11)

Modelo_12 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`Altura (cm)` 
                + Dados$`Massa C (kg)` + Dados$Potência)
summary(Modelo_12)

Modelo_13 <- lm(Dados$`Y_1K-Pista` ~ Dados$Sexo + Dados$`Altura (cm)` 
                + Dados$`Massa C (kg)` + Dados$Força)
summary(Modelo_13)


#### Modelos para 1km em SUBIDA

Y_Subida <- Dados$`Y_1K-Subida`

Modelo_01 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`Massa C (kg)` 
                + Dados$`Altura (cm)`)
summary(Modelo_01)

Modelo_02 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`Massa C (kg)` 
                + Dados$`Altura (cm)` + Dados$`IMC(k/cm2)`)
summary(Modelo_02)

Modelo_03 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`IMC(k/cm2)`)
summary(Modelo_03)

Modelo_04 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Salto-Queda` )
summary(Modelo_04)

Modelo_05 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Salto Aga`)
summary(Modelo_05)

Modelo_06 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Soma 7 DC`)
summary(Modelo_06)

Modelo_07 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Soma 7 DC` + Dados$`Elástico 1`)
summary(Modelo_07)

Modelo_08 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo  + Dados$`IMC(k/cm2)` + Dados$Potência)
summary(Modelo_08)

Modelo_09 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo  + Dados$`IMC(k/cm2)` + Dados$Força)
summary(Modelo_09)

Modelo_10 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo  + Dados$`Soma 7 DC` + Dados$Potência)
summary(Modelo_10)

Modelo_11 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo  + Dados$`Soma 7 DC` + Dados$Força)
summary(Modelo_11)

Modelo_12 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`Altura (cm)` 
                + Dados$`Massa C (kg)` + Dados$Potência)
summary(Modelo_12)

Modelo_13 <- lm(Dados$`Y_1K-Subida` ~ Dados$Sexo + Dados$`Altura (cm)` 
                + Dados$`Massa C (kg)` + Dados$Força)
summary(Modelo_13)

#### Modelos para 1km em TRILHA

Y_Trilha <- Dados$`Y_1K-Trilha`

Modelo_01 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`Massa C (kg)` + Dados$`Altura (cm)`)
summary(Modelo_01)

Modelo_02 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`Massa C (kg)` + Dados$`Altura (cm)` + Dados$`IMC(k/cm2)`)
summary(Modelo_02)

Modelo_03 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`IMC(k/cm2)`)
summary(Modelo_03)

Modelo_04 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Salto-Queda` )
summary(Modelo_04)

Modelo_05 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Salto Aga`)
summary(Modelo_05)

Modelo_06 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Soma 3 Saltos`)
summary(Modelo_06)

Modelo_07 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Soma 7 DC`)
summary(Modelo_07)

Modelo_08 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`IMC(k/cm2)` 
                + Dados$`Soma 7 DC` + Dados$`Elástico 2`)
summary(Modelo_08)

Modelo_09 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo  + Dados$`IMC(k/cm2)` + Dados$Potência)
summary(Modelo_09)

Modelo_10 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo  + Dados$`IMC(k/cm2)` + Dados$Força)
summary(Modelo_10)

Modelo_11 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`Altura (cm)` 
                + Dados$`Massa C (kg)` + Dados$Potência)
summary(Modelo_11)

Modelo_12 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`Altura (cm)` 
                + Dados$`Massa C (kg)` + Dados$Força)
summary(Modelo_12)


#### Modelos para relação entre PISTA, SUBIDA e TRILHA

Modelo_1 <- lm(Dados$`Y_1K-Pista` ~ Dados$`Y_1K-Subida`)
summary(Modelo_1)

Modelo_2 <- lm(Dados$`Y_1K-Pista` ~ Dados$`Y_1K-Trilha`)
summary(Modelo_2)

Modelo_3 <- lm(Dados$`Y_1K-Pista` ~ Dados$`Y_1K-Subida` + Dados$`Y_1K-Trilha`)
summary(Modelo_3)

Modelo_4 <- lm(Dados$`Z_1K-Pista` ~ - 1 + Dados$`Z_1K-Subida` + Dados$`Z_1K-Trilha`)
summary(Modelo_4)

Modelo_5 <- lm(Dados$`Y_1K-Subida` ~ Dados$`Y_1K-Pista`)
summary(Modelo_5)

Modelo_6 <- lm(Dados$`Y_1K-Subida` ~ Dados$`Y_1K-Trilha`)
summary(Modelo_6)

Modelo_7 <- lm(Dados$`Y_1K-Subida` ~ Dados$`Y_1K-Pista` + Dados$`Y_1K-Trilha`)
summary(Modelo_7)

Modelo_8 <- lm(Dados$`Z_1K-Subida` ~ - 1 + Dados$`Z_1K-Pista` + Dados$`Z_1K-Trilha`)
summary(Modelo_8)

Modelo_9 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`Y_1K-Pista`)
summary(Modelo_9)

Modelo_10 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`Y_1K-Subida`)
summary(Modelo_10)

Modelo_11 <- lm(Dados$`Y_1K-Trilha` ~ Dados$Sexo + Dados$`Y_1K-Pista` + Dados$`Y_1K-Subida`)
summary(Modelo_11)

Modelo_12 <- lm(Dados$`Z_1K-Trilha` ~ Dados$Sexo + Dados$`Z_1K-Pista` + Dados$`Z_1K-Subida`)
summary(Modelo_12)
